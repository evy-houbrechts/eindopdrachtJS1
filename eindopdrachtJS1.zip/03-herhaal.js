"use strict";
function toonTekst(){
    for( let i = 1; i<= 6; i++){
        document.write (`<p>Herhaling: ${[i]}</p>`);
    }
}